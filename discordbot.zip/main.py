import os
import discord
from random import randrange
from datetime import date
import xlrd
from openpyxl import Workbook
import csv
import matplotlib.pyplot as plt
y=[]
#with open('l.csv', 'r') as file:
   
  
  
   # reader = csv.reader(file)
    #for i in reader:
     # y.append(i)  
        
# corresponding y axis values
x=[]
#for i in range(1000):
  #x.append(i)
    
  
plt.xlabel('x - axis')
# naming the y axis
plt.ylabel('y - axis')
  
# giving a title to my graph
plt.title('My first graph!')
#plt.plot(x, y)
# function to show the plot
#plt.show()
  
# plotting the points 

loc = ("l.csv")
p=False
l=False
o=False
if p:
  loc = ('l.csv')





  
    
    
    
# Extracting number of rows
today = date.today()
sets=["PlasticMarinePollutionGlobalDataset.xlsx", 
]
randomfacts=["China 59,079,741 tons", "United States 37,825,550 tons", "Germany 14,476,561 tons", "Brazil 11,852,055 tons", "Japan 7,993,489 tons", "Pakistan 6,412,210 tons", "Nigeria 5,961,750 tons", "Russia 5,839,685 tons", "as of ", today  ]

myList= [discord.Embed(title="oceanfirstinstitute",url="https://www.oceanfirstinstitute.org/?gclid=EAIaIQobChMIr97qgMjx9wIVtx-tBh1LPwtaEAAYAiAAEgI9NPD_BwE"  ,description="research group that promotes helping people about ocean safety and health. Has great research opportunities and internships as well!", color=0x00ff00),discord.Embed(title="Oceana",url="https://oceana.org/"  ,description="A very big organazation that helps save the ocean in the goal that it can provide more food to people around the world. Also helps scientists promote their papers on sealife.", color=0x00ff00) ]
myList[0].set_thumbnail(url="https://nfg-sofun.s3.amazonaws.com/uploads/project/photo/70404/poster_board_Clinton_Bauder_2_copy.jpg",)
myList[1].set_thumbnail(url = "https://www.pewtrusts.org/-/media/post-launch-images/2018/10/pew-2018-julio---jpb/16x9_m.jpg")
client=discord.Client()


@client.event


async def on_ready():
  print('we have logged in as user {0.user}'.format(client))

@client.event

async def on_message(message):
  if message.author == client.user:
    return

  if message.content.startswith('$hello'):
  
    await message.channel.send('hello')
  if message.content.startswith('$help'):
        embedVar = discord.Embed(title="Help commands " , description="commands that are available from the bot",       
        color=0x00ff00)
        embedVar.add_field(name="$conservation", value="conservation website and description of it random one pops up each time ", inline=False)
        embedVar.add_field(name="Field2", value="hi2", inline=False)
        await message.channel.send(embed=embedVar)
  if message.content.startswith('$conservation'):
    await message.channel.send(embed=myList[randrange(2)])
  if message.content.startswith('$pollutionstats'):
    for i in range(len(randomfacts)):
      await message.channel.send(randomfacts[i])
  if message.content.startswith(" I threw away trash"):
    emoji = '\N{THUMBS UP SIGN}'
    await message.add_reaction(emoji)
    await message.channel.send("Good job")
  if message.content.startswith("$dataset"):
    await message.channel.send("which dataset would you like to visualize?")
    #if(message.content.startswith("option 1"))

  
my_secret = os.environ['TOKEN']
client.run(my_secret)
