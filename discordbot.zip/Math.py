import xlrd

import matplotlib.pyplot as plt

 x = [1,2,3]
# corresponding y axis values
y = [2,4,1]
  
# plotting the points 
plt.plot(x, y)
    
    
    
# Extracting number of rows
